import json
import boto3
import psycopg2

def lambda_handler(event, context):
    credential = getCredentials()
    connection = psycopg2.connect(user=credential['username'], password=credential['password'], host=credential['host'], database=credential['db'])
    cursor = connection.cursor()
    query = "SELECT version() AS version"
    cursor.execute(query)
    results = cursor.fetchone()
    cursor.close()
    connection.commit()
    return results

def getCredentials():
    credential = {}
    
    secret_name = "mysecretname"
    region_name = "us-east-1"
    
    client = boto3.client(
      service_name='secretsmanager',
      region_name=region_name
    )
    
    get_secret_value_response = client.get_secret_value(
      SecretId=secret_name
    )
    
    secret = json.loads(get_secret_value_response['SecretString'])
    
    credential['username'] = secret['username']
    credential['password'] = secret['password']
    credential['host'] = "database-1-instance-1.c9gpmnbx3rln.us-east-1.rds.amazonaws.com"
    credential['db'] = "postgres"
    
    return credential            
                

